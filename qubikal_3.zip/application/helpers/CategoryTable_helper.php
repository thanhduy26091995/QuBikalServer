<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class CategoryTable {

    public $_TABLE_NAME = "qu_category";
    public $_ID = "id";
    public $_NAME = "name";

}
