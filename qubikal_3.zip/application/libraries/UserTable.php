<?php

class UserTable{
	public $TABLE_NAME = "qu_user";
	public $ID = "id";
	public $USER_NAME = "user_name";
	public $FULL_NAME = "full_name";
	public $CREATED_DATE = "created_date";
}