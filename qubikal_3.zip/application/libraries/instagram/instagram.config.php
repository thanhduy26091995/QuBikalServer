<?php
$instagram = new Instagram(array(
'apiKey' => 'd80c35d2c9614d078afc0b690cb39553',
'apiSecret' => '0254c77f6fc440dd9e202323c8337bf2',
'apiCallback' => 'http://localhost/qubikal/home/loginresult' // Callback URL
));
?>