<?php

class PhotoTable{
	public $TABLE_NAME = "qu_photos";
	public $ID = "id";
	public $NAME = "name";
	public $IMAGE_PATH = "image_path";
	public $CREATED_DATE = "created_date";
	public $CATEGORY_ID = "qu_category_id";
}