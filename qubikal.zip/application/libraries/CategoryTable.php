<?php

class CategoryTable{
	public $TABLE_NAME = "qu_category";
	public $ID = "id";
	public $NAME = "name";
        public $IMAGE_PATH = "name";
	public $PHOTO_COUNT = "photo_count";
	public $CREATED_DATE = "created_date";
	public $PARENT_ID = "qu_category_id";
}